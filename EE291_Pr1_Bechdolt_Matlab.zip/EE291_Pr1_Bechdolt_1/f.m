function[value] = f(a)
   value = -(50*(3*a^2 - 100000*a + 10000000))/(3*a^2 + 10000000); 
end